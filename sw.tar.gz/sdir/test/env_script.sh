#!/bin/bash

echo "ENV1 = ${NEW_ENV1}"
echo "ENV2 = ${NEW_ENV2}"
echo "ENV3 = ${NEW_ENV3}"
